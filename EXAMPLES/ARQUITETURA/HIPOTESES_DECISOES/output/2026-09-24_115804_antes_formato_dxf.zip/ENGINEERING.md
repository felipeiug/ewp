# ENGINEERING — Projeto arquitetônico completo

## Identificação

- Projeto: Casa 001
- Responsável: Felipe Emanuel Domiciano Ribeiro
- Data de início: 2026-09-24
- Cliente: José da Silva
- Endereço: Rua Oliveira - N° 1356. Bairro Cruzeiro. Belo Horizonte - MG CEP: 30310-150


- Status: INICIAL — CONTEXTO A CONFIRMAR
- Justificativa (2026-09-24): contexto e geometria ainda possuem lacunas; nenhuma etapa técnica aprovada. O diagnóstico documental não representa conclusão da etapa 00.

## Objetivo

Você deve atuar como arquiteto/engenheiro e, a partir de um croqui com medidas, você deverá gerar:
- A plata baixa e cortes para o autocad;
- O projeto arquitetônico completo em 3D para o sketchup;
- As plantas em folha A1 no formato PDF.

## Escopo

Realizar a interpretação do Croquí em `00_dados/input/croqui.jpg`, cujas cotas explícitas estão em metros (conversão para centímetros registrada na etapa 00) e, a partir dele, desenvolver o que é pedido.

O croquí trata-se de uma residência de medio-alto padrão e está em metros, porém não fica em um condomínio então as medidas de segurança devem ser respeitadas dado a localização do imóvel.
O croqui apresenta os dados em metros, porém neste projeto tudo devera ser cotado em centímetros, inclusive o projeto em 3D no sketchup.

Não inclui aprovação legal automática, levantamento topográfico, sondagem, projeto estrutural, instalações prediais, orçamento executivo ou responsabilidade técnica de execução e informações específicas para essas disciplinas.


## Entradas

- Croqui feito à mão com medidas: `00_dados/input/croqui.jpg`;
- Tipo de edificação e uso: Disponível em `REQUISITOS/convencoes.md`;
- Dimensões e orientação do lote, níveis e topografia: Disponível em `REQUISITOS/convencoes.md`;
- Metregem construida, área verde, espaçamentos das bordas do lote em `NORMAS/plano_diretor_bh.pdf`;
- Programa de necessidades, preferências de materiais e padrão de representação: `REQUISITOS/convencoes.md`;
- A versão do Sketchup é a de 2016 e a do AutoCAD de 2019.

## Entregáveis

- registro do croqui de entrada, inventário de medidas;
- plantas baixas, cortes, fachadas e detalhes em arquivos editáveis do AutoCAD;
- modelo 3D coordenado em arquivo editável do SketchUp;
- pranchas diagramadas e versões finais em PDF;
- relatório de compatibilização, revisões, limitações e arquivos entregues.

## Critérios de aceitação

1. Todas as cotas usadas no desenho estão rastreáveis ao croqui ou a uma decisão registrada.
2. Plantas, cortes, fachadas e modelo 3D usam a mesma versão de medidas, níveis e nomenclatura.
3. Arquivos editáveis do AutoCAD e SketchUp abrem no ambiente de referência e mantêm escala, unidades, layers/tags e referências necessárias.
4. PDFs finais têm pranchas legíveis, carimbo, escala gráfica ou numérica, norte quando aplicável, revisão e identificação do projeto.
5. Nenhuma medida ausente, inferência de projeto ou incompatibilidade é ocultada e deve, obrigatóriamente, ser solicitada ao usuário.
6. Os entregáveis finais são reproduzíveis a partir do croqui, decisões registradas e arquivos-fonte preservados.

## Histórico

- 2026-09-20 — Estrutura criada e fluxo inicial definido para previsão de vazões.
- 2026-09-24 — Escopo alterado para projeto arquitetônico completo com entregáveis SketchUp, AutoCAD e PDF.

## Step by Step

O fluxo abaixo é a única sequência vigente, por instrução expressa do usuário em 2026-09-24. Executar na ordem 00 → 01 → 02 → 03 → 04, respeitando os gates. As correções propostas de dependências das etapas 03 e 04 ainda precisam de confirmação; não habilitam avanço.

### 00 — Dados

- Situação: diagnóstico documental realizado; etapa aberta, sem DWG/SKP validado e sem aprovação.
- Pré-requisitos da geometria: esclarecer referências das cotas, espessuras, vãos, orientação, níveis, implantação e condicionantes urbanísticas do lote.
- Trabalho independente autorizado: regularização documental, inventário, conversões explícitas e identificação de lacunas.
- Gate: resolver pendências críticas, conferir os editáveis nas versões de referência e obter aprovação expressa da etapa 00 antes de avançar.

- Verificar croqui feito à mão com medidas em `00_dados/input/` e informar inconsistências, ambiente inacessíveis ou fora de padrão e outros dados que sejam necessários.
- Saída: arquivo da planta baixa `.dwg` e residência, somente paredes, `.skp` salvo em `00_dados/output/`.
- Validação: confirmar uso, local, lote, orientação, níveis, medidas críticas, legislação e formatos de entrega.

### 01 — Render 3D

- Dependência: etapa 00 aprovada.
- Gerar o projeto SKP 3D com móveis e ambientação, gerar também uma imagem da renderização do imóvel vista de cima e da fachada, gerar por IA e não pelo software.
- Entrada: DWG e SKP disponíveis em `00_dados/output/` na versão mais recente.
- Saída: `01_estudo_preliminar/output/`.
- Validação: ambientes, fluxos, áreas, dimensões e premissas conferidos.

### 02 — Desenvolvimento 2D no AutoCAD

- Dependência: etapa 00 aprovada.
- Entrada: DWG e SKP disponíveis em `00_dados/output/` na versão mais recente.
- Saída: planta baixa, implantação, cortes, fachadas, cotas, níveis, layers e arquivo editável `.dwg` em `02_autocad/output/`.
- Validação: escala, unidades, espessuras, vãos, cotas, níveis, referências cruzadas e adequação ao plano diretor do município.

### 03 — Compatibilização e documentação final

- Dependência proposta, A CONFIRMAR: etapas 01 e 02 revisadas. A dependência anterior era circular (02 e 03). Sem confirmação, esta etapa não pode iniciar.
- Entrada: DWG, SKP, decisões e lista de pendências.
- Saída: desenhos finais, pranchas, carimbo, lista de arquivos e PDFs em `03_projeto/output/`.
- Validação: conferência folha a folha, legibilidade, escala, revisão, consistência 2D/3D e ausência de pendências críticas.

### 04 — Relatório e entrega

- Dependência proposta, A CONFIRMAR: etapa 03 aprovada. A dependência anterior era circular (04). Sem confirmação, esta etapa não pode iniciar.
- Entrada: todos os arquivos-fonte e PDFs emitidos.
- Saída: relatório compilado em `.tex` e `.pdf`, índice de entregáveis, premissas, limitações e histórico de revisões em `04_relatorio/output/`.
- Validação: abrir os arquivos entregues, verificar links/referências e confirmar que o conjunto é reproduzível a partir do croqui preservado.

## Pendências e próximo passo — 2026-09-24

- Consultar `00_dados/output/jose_da_silva_00_diagnostico_v01.md` e o inventário correspondente.
- Confirmar unidade dos níveis, orientação, implantação, paredes, vãos e referências das cotas; obter identificação cadastral e parâmetros urbanísticos do lote.
- Disponibilidade do executável não comprova licença, funcionamento ou abertura de entregáveis.
- Permanecer na etapa 00; próximos desenhos dependem das respostas e dos testes de ferramentas.
- Os diretórios das etapas posteriores serão criados apenas ao atingir cada etapa.

### Adendo ao histórico — 2026-09-24

Regularização estrutural e diagnóstico autorizados pelo usuário. O Step by Step foi incorporado neste documento; o fluxo externo foi identificado como histórico. Corrigidos caminhos para `00_dados`; novas dependências de 03 e 04 permanecem propostas. Os requisitos originais e o croqui foram preservados. Nenhuma aprovação de etapa foi inferida.
